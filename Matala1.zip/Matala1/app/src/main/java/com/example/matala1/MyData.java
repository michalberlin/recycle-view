package com.example.matala1;

public class MyData {

    static String[] nameArray = {"Ninet_Levy", "Miki_Applebaum", "Noa_Shahar", "Dana_Schnir", "Nachi",
            "Yardena_Tamir", "Doron_Sade","Zohar_Lahat", "Naomi_Shahar", "Givon_Kaspi"};
    static String[] Description = {"Student at the music school", "Student at the music school",
            "Student at the music school", "Student at the music school", "Student at the music school",
            "Director of the music school", "Singing teacher at the music school", "Student at the music school",
            "Noa Shahar's Mother", "Noa Shahar's agent"};

    static Integer[] drawableArray = {R.drawable.ninet_levy, R.drawable.miki_applebaum, R.drawable.noa_shahar,
            R.drawable.dana_schnir, R.drawable.nachi, R.drawable.yardena_tamir, R.drawable.doron_sade,
            R.drawable.zohar_lahat, R.drawable.naomi_shahar, R.drawable.givon_kaspi};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
}
